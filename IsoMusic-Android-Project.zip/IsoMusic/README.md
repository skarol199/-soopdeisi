# Iso Music — Android APK projesi

Modern koyu temalı yerel müzik çalar için başlangıç projesi.

## Mevcut özellikler
- Android MediaStore üzerinden telefondaki müzikleri listeler.
- Arama (başlık/sanatçı), basit çalma listesine ekleme.
- Oynat/duraklat, önceki/sonraki parça.
- Doğrudan erişilebilir MP3/AAC/uyumlu ses akışı URL'si çalma.
- Android `Equalizer` API'si ile bant ayarı (cihaz destekliyorsa).
- Şarkı sözleri düğmesi şu an yer tutucudur; gerçek sözler için lisanslı API ve anahtar gerekir.

## APK derleme
1. Bilgisayara Android Studio (güncel kararlı sürüm) ve JDK 17 kurun.
2. Android Studio > **Open** ile bu klasörü açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
5. Debug APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.
6. APK'yı telefona aktarın ve kurulum için Android'in istediği izni verin.

Komut satırı (Android SDK ve Gradle/Android Studio kurulumu gerekir):
`gradle assembleDebug`

## Önemli sınırlamalar
- Bu ilk sürüm bir başlangıç MVP'sidir; burada derlenmiş APK sağlanmış değildir.
- İnternet sekmesi katalog/arama servisi değildir: kullanıcı doğrudan ses dosyası/akış URL'si girmelidir. Spotify/YouTube gibi servislerden içerik çekmez.
- Şarkı sözleri otomatik gelmez; uygun lisanslı bir servis entegrasyonu gerekir.
- Arka planda çalma bu başlangıç sürümünde Android servisi/medya bildirimiyle tam uygulanmış değildir. Ekran kapanınca sistem davranışı garanti edilmez. Üretim sürümü için Media3 ExoPlayer + MediaSessionService eklenmelidir.
- Android 13+ ses izni, daha eski Android sürümlerinde depolama izni istenir.
