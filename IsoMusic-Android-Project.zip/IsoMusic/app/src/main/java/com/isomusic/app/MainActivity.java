package com.isomusic.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(12,12,15), PANEL = Color.rgb(26,26,32), WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(160,160,172), ACCENT = Color.rgb(180,135,255);
    private LinearLayout root, listBox, nowBox;
    private EditText searchBox, urlBox;
    private TextView status, titleNow, artistNow;
    private MediaPlayer player;
    private Equalizer equalizer;
    private final ArrayList<Track> tracks = new ArrayList<>();
    private final ArrayList<Track> playlist = new ArrayList<>();
    private boolean showPlaylist = false;
    private String activeTab = "Tümü";
    private static class Track {
        String title, artist; Uri uri;
        Track(String t, String a, Uri u) { title=t; artist=a; uri=u; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUI();
        if (hasAudioPermission()) loadTracks(); else requestAudioPermission();
    }
    private boolean hasAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)==PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, 12);
        else if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 12);
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r==12 && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) loadTracks();
        else status.setText("Müzikleri görmek için ses dosyası izni gerekli.");
    }

    private void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(20),dp(20),dp(8)); root.setBackgroundColor(BG);
        setContentView(root);
        TextView brand = text("ISO MUSIC", 25, WHITE, true); root.addView(brand);
        TextView subtitle = text("Müziğin, senin ritmin.", 13, MUTED, false); root.addView(subtitle, lp(-1,-2,0,0,0,16));
        searchBox = new EditText(this); searchBox.setSingleLine(true); searchBox.setTextColor(WHITE); searchBox.setHintTextColor(MUTED); searchBox.setHint("Şarkı veya sanatçı ara");
        searchBox.setCompoundDrawablePadding(dp(8)); searchBox.setPadding(dp(14),dp(10),dp(14),dp(10)); searchBox.setBackground(round(PANEL,14));
        root.addView(searchBox, lp(-1,dp(48),0,0,0,12));
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderList(); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        HorizontalScrollView tabs = new HorizontalScrollView(this); tabs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow = new LinearLayout(this); tabRow.setOrientation(LinearLayout.HORIZONTAL);
        for (String t : new String[]{"Tümü","Çalma listem","İnternet"}) {
            Button b = button(t, t.equals("Tümü")); b.setOnClickListener(v -> {
                activeTab=t; showPlaylist=t.equals("Çalma listem"); renderList();
                status.setText(t.equals("İnternet")?"İnternet sekmesi: desteklenen doğrudan ses bağlantısını aşağıya yapıştır.":"");
            });
            tabRow.addView(b, lp(-2,dp(40),0,0,8,0));
        }
        tabs.addView(tabRow); root.addView(tabs,lp(-1,dp(44),0,0,0,10));
        status = text("Telefonundaki müzikler yükleniyor…",12,MUTED,false); root.addView(status,lp(-1,-2,0,0,0,8));
        ScrollView scroll = new ScrollView(this); listBox = new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nowBox = new LinearLayout(this); nowBox.setOrientation(LinearLayout.VERTICAL); nowBox.setPadding(dp(14),dp(12),dp(14),dp(12)); nowBox.setBackground(round(PANEL,18));
        titleNow = text("Henüz bir şarkı seçilmedi",15,WHITE,true); artistNow = text("Bir parça seçerek başla",12,MUTED,false);
        nowBox.addView(titleNow); nowBox.addView(artistNow,lp(-1,-2,0,4,0,8));
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); 
        Button prev=button("|◀",false), play=button("▶ / ❚❚",true), next=button("▶|",false), eq=button("EQ",false);
        prev.setOnClickListener(v -> step(-1)); next.setOnClickListener(v -> step(1));
        play.setOnClickListener(v -> { if(player!=null && player.isPlaying()){player.pause();play.setText("▶");} else if(player!=null){player.start();play.setText("❚❚");} });
        eq.setOnClickListener(v -> openEqualizer());
        controls.addView(prev); controls.addView(play); controls.addView(next); controls.addView(eq); nowBox.addView(controls);
        root.addView(nowBox,lp(-1,-2,0,8,0,0));
        urlBox = new EditText(this); urlBox.setSingleLine(true); urlBox.setTextColor(WHITE); urlBox.setHintTextColor(MUTED); urlBox.setHint("Doğrudan MP3 / ses URL'si");
        urlBox.setPadding(dp(12),dp(8),dp(12),dp(8)); urlBox.setBackground(round(PANEL,12));
        Button stream = button("Çal",true);
        stream.setOnClickListener(v -> playUrl(urlBox.getText().toString().trim()));
        LinearLayout online = new LinearLayout(this); online.setOrientation(LinearLayout.HORIZONTAL); online.addView(urlBox,new LinearLayout.LayoutParams(0,dp(46),1)); online.addView(stream,lp(dp(68),dp(46),8,0,0,0));
        root.addView(online,lp(-1,-2,0,8,0,4));
        TextView foot=text("İnternet: yalnızca doğrudan erişilebilir ve izinli ses bağlantıları.",10,MUTED,false); root.addView(foot);
    }

    private void loadTracks() {
        tracks.clear();
        Uri collection = Build.VERSION.SDK_INT >= 29 ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST};
        try (Cursor c = getContentResolver().query(collection, projection, MediaStore.Audio.Media.IS_MUSIC+" != 0", null, MediaStore.Audio.Media.TITLE+" ASC")) {
            if(c!=null) while(c.moveToNext()) {
                long id=c.getLong(0); String t=c.getString(1), a=c.getString(2);
                tracks.add(new Track(t==null?"Bilinmeyen parça":t,a==null?"Bilinmeyen sanatçı":a,ContentUris.withAppendedId(collection,id)));
            }
        } catch(Exception e) { status.setText("Müzikler okunamadı: "+e.getMessage()); }
        status.setText(tracks.size()+" parça bulundu");
        renderList();
    }
    private void renderList() {
        if(listBox==null) return; listBox.removeAllViews();
        ArrayList<Track> source = showPlaylist ? playlist : tracks;
        String q=searchBox==null?"":searchBox.getText().toString().toLowerCase(Locale.ROOT).trim();
        int count=0;
        for(Track tr:source) {
            if(!tr.title.toLowerCase(Locale.ROOT).contains(q) && !tr.artist.toLowerCase(Locale.ROOT).contains(q)) continue;
            LinearLayout item=new LinearLayout(this); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(12),dp(10),dp(8),dp(10)); item.setBackground(round(PANEL,14));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            TextView t=text(tr.title,14,WHITE,true), a=text(tr.artist,12,MUTED,false); info.addView(t); info.addView(a);
            item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button add=button("＋",false); add.setOnClickListener(v->{if(!playlist.contains(tr)) playlist.add(tr); Toast.makeText(this,"Çalma listene eklendi",Toast.LENGTH_SHORT).show();});
            Button lyrics=button("♪",false); lyrics.setOnClickListener(v -> {
                new android.app.AlertDialog.Builder(this).setTitle("Şarkı sözleri")
                    .setMessage("Şarkı: "+tr.title+"\nSanatçı: "+tr.artist+"\n\nBu sürümde sözler otomatik olarak alınmıyor. Şarkı sözlerini görüntülemek için lisanslı bir söz servisi/API entegrasyonu eklenebilir.")
                    .setPositiveButton("Tamam",null).show();
            });
            item.addView(add); item.addView(lyrics);
            item.setOnClickListener(v->playTrack(tr));
            listBox.addView(item,lp(-1,-2,0,0,0,8)); count++;
        }
        if(count==0) {
            TextView empty=text(showPlaylist?"Çalma listen henüz boş. ＋ ile parça ekle.":(q.isEmpty()?"Telefonunda müzik bulunamadı. MP3 dosyası ekleyebilir veya URL deneyebilirsin.":"Aramana uygun parça bulunamadı."),13,MUTED,false);
            empty.setPadding(dp(6),dp(20),dp(6),dp(20)); listBox.addView(empty);
        }
    }
    private void playTrack(Track tr) {
        try {
            if(player!=null){player.release();player=null;}
            player=new MediaPlayer(); player.setAudioStreamType(AudioManager.STREAM_MUSIC); player.setDataSource(this,tr.uri); player.setOnPreparedListener(mp->{mp.start();titleNow.setText(tr.title);artistNow.setText(tr.artist); if(equalizer!=null)equalizer.release(); try{equalizer=new Equalizer(0,mp.getAudioSessionId());equalizer.setEnabled(true);}catch(Exception ignored){}});
            player.setOnCompletionListener(mp->step(1)); player.setOnErrorListener((mp,what,extra)->{status.setText("Bu dosya çalınamadı.");return true;}); player.prepareAsync();
            status.setText("Çalınıyor: "+tr.title);
        } catch(Exception e){status.setText("Çalma hatası: "+e.getMessage());}
    }
    private void playUrl(String url) {
        if(url.isEmpty()){urlBox.setError("Bir doğrudan ses URL'si gir");return;}
        try {
            if(player!=null){player.release();player=null;}
            player=new MediaPlayer(); player.setAudioStreamType(AudioManager.STREAM_MUSIC); player.setDataSource(url);
            player.setOnPreparedListener(mp->{mp.start();titleNow.setText("İnternet yayını");artistNow.setText(Uri.parse(url).getHost()==null?url:Uri.parse(url).getHost());status.setText("İnternetten çalınıyor");try{if(equalizer!=null)equalizer.release();equalizer=new Equalizer(0,mp.getAudioSessionId());equalizer.setEnabled(true);}catch(Exception ignored){}});
            player.setOnErrorListener((mp,w,e)->{status.setText("Bağlantı açılamadı. Doğrudan MP3/AAC/akış URL'si deneyin.");return true;});
            player.prepareAsync();
        } catch(Exception e){status.setText("URL açılamadı: "+e.getMessage());}
    }
    private void step(int d) {
        if(tracks.isEmpty()) return; int idx=0;
        if(titleNow!=null) for(int i=0;i<tracks.size();i++) if(tracks.get(i).title.equals(titleNow.getText().toString())){idx=i;break;}
        idx=(idx+d+tracks.size())%tracks.size(); playTrack(tracks.get(idx));
    }
    private void openEqualizer() {
        if(player==null){new android.app.AlertDialog.Builder(this).setMessage("Önce bir şarkı başlat.").setPositiveButton("Tamam",null).show();return;}
        try {
            if(equalizer==null) equalizer=new Equalizer(0,player.getAudioSessionId());
            LinearLayout layout=new LinearLayout(this); layout.setPadding(dp(20),dp(12),dp(20),dp(12)); layout.setOrientation(LinearLayout.VERTICAL);
            short bands=equalizer.getNumberOfBands(); short[] range=equalizer.getBandLevelRange();
            for(short i=0;i<bands;i++){
                final short band=i; TextView label=text((equalizer.getCenterFreq(i)/1000f)+" kHz",12,WHITE,false); layout.addView(label);
                SeekBar seek=new SeekBar(this); seek.setMax(range[1]-range[0]); seek.setProgress(equalizer.getBandLevel(i)-range[0]);
                seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){if(u)equalizer.setBandLevel(band,(short)(p+range[0]));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
                layout.addView(seek);
            }
            new android.app.AlertDialog.Builder(this).setTitle("Ekolayzır").setView(layout).setPositiveButton("Bitti",null).show();
        } catch(Exception e){status.setText("Ekolayzır bu cihazda kullanılamıyor.");}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackground(round(primary?Color.rgb(104,70,170):PANEL,12));b.setPadding(dp(8),0,dp(8),0);return b;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){if(player!=null){player.release();player=null;}if(equalizer!=null){equalizer.release();equalizer=null;}super.onDestroy();}
}
